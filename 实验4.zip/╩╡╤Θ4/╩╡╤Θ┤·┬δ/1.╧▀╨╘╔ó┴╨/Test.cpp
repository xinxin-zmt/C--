#include "Hash.cpp"

#include <iostream>
using namespace std;

void main()
{ 
	int a[5]={89,18,49,58,69};
	Hash<int> hashlist(10);
	for(int i=0; i<5; i++)
		hashlist.Insert(a[i]);
	cout<<"The state of the hash table is as following:"<<endl;
	hashlist.show();
	cout<<"The location of each item in the hash table can be found as following:"<<endl;
	for(i=0; i<5; i++)
		cout<<a[i]<<":"<<hashlist.Find(a[i])<<endl;
}